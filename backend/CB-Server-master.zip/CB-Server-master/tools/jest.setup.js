/* eslint-disable no-undef */

jasmine.DEFAULT_TIMEOUT_INTERVAL = 20000;
