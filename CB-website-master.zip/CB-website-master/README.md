TODO
- [ ] Profile page
- [ ] Signup UI + UI for login + Pop up
- [ ] Adding side padding for pages > 1440px width
- [ ] Remove caching
